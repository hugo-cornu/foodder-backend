require("../db/index")
const City = require("../models/City.model")
const Country = require("../models/Country.model")
const cities = [
  {
    cityName: "Paris",
    country: "FR",
  },
  {
    cityName: "Madrid",
    country: "ES",
  },
  {
    cityName: "Milan",
    country: "IT",
  },
  {
    cityName: "Rome",
    country: "IT",
  },
  {
    cityName: "London",
    country: "EN",
  },
  {
    cityName: "Berlin",
    country: "DE",
  },
  {
    cityName: "Brussels",
    country: "BE",
  },
  {
    cityName: "Hanoi",
    country: "VN",
  },
]

seed()
async function seed() {
  const allPromises = await Promise.all(
    cities.map(async (city) => {
      const country = await Country.findOne({ countryCca2: city.country })
      // city.countryCca2 = country._id
      // console.log(country)
      return { cityName: city.cityName, country: country._id }
    })
  )
  console.log(allPromises)
  const city = await City.create(allPromises)

  console.log(city)
  process.exit()
}
