//MANUAL SEED
const mongoose = require("mongoose")
const User = require("../models/User.model")
const Article = require("../models/Article.model")
const City = require("../models/City.model")

require("../db/index.js")

const articles = [
  {
    title: "Eggs Benedict",
    description: "Incredible!",
    image:
      "https://tastesbetterfromscratch.com/wp-content/uploads/2013/08/Eggs-Benedict-11-300x300.jpg",
    countryCca2: "FR",
    city: "Paris",
    restaurant: "Bouillon",
    private: true,
  },
  {
    title: "Escargots au beurre persillé",
    description:
      "Première fois que je goûte des escargots à l'ail. Disons que j'y allais un peu à reculons. Au final, c'est vraiment excellent !",
    image:
      "https://d36qbsb0kq4ix7.cloudfront.net/images/mmc/escargot-beurre-persille.jpg",
    countryCca2: "FR",
    city: "Paris",
    restaurant: "Chez Fernand Christine",
    private: false,
  },
  {
    title: "Magret de canard & champignons",
    description:
      "Un classiques de la cuisine du sud-ouest et française en général.",
    image:
      "https://www.epicurien.be/magazine/00-img-epicurien/recettes-w800/magret-de-canard-grille-four.jpg",
    countryCca2: "FR",
    city: "Paris",
    private: false,
  },
  {
    title: "ho Bò, la soupe vietnamienne",
    description:
      "Soupe phở est une recette traditionnelle de cuisine vietnamienne, à base de bouillon de viande et de nouilles de riz, agrémentés de divers ingrédients. D'ailleurs, je ne savais pas mais : Le nom phở ou pho viendrait probablement du mot français pot-au-feu en rapport avec l'époque de l'Indochine.",
    image:
      "https://authentikvietnam.com/media/blog/recette-pho-bo-nouilles-boeuf.jpg",
    countryCca2: "VN",
    city: "Hanoi",
    private: false,
  },
  {
    title: "Tortilla espagnole",
    description:
      "Institution en Espagne et je comprends pourquoi ! Avec oignons ou sans, à la truffe, au chorzo... on en a pour tous les goûts. Magnifique 👀",
    image:
      "https://media-cdn.tripadvisor.com/media/photo-s/0d/f8/c5/89/20161226-134437-largejpg.jpg",
    countryCca2: "ES",
    city: "Madrid",
    private: false,
  },
  {
    title: "Typique Currywurst de lendemain de soirée",
    description:
      "Quoi dire... 😅 Ce n'est pas la plus grande gastro connue mais... ça fait toujours plaisir entre collègue en lendemain de soirée à écouter de la bonne micro-house",
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Currywurst_%26_Pommes_frites.jpg/1200px-Currywurst_%26_Pommes_frites.jpg",
    countryCca2: "DE",
    city: "Berlin",
    private: false,
  },
]

async function seedArticles() {
  const allUsers = await User.find()
  const allCities = await City.find()
  const createdArticles = await Article.create(
    await Promise.all(
      articles.map(async (article) => ({
        ...article,
        author: allUsers[Math.floor(Math.random() * allUsers.length)]._id,
        city: allCities[Math.floor(Math.random() * allCities.length)]._id,
      }))
    )
  )
  console.log("createdArticles:", createdArticles)
  console.log(`Created ${createdArticles.length} articles.`)
  await mongoose.connection.close()
  console.log("Connection closed.")
  process.exit()
}

seedArticles()
